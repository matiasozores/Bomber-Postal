package main.entities.characters;

public class Suicide {

}
